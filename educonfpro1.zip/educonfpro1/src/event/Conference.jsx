// src/event/Conference.jsx
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Header from "../pages/Header";
import Footer from "../pages/Footer";
import { getCurrentUser, updateCurrentUser, getAllEvents } from "../utils/localStorageUtils"; 
import "../pages/Home.css"; // Home page ka theme CSS

const Conference = () => {
  const navigate = useNavigate();
  const [events, setEvents] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");

  // ✅ Events load karo from localStorage
  useEffect(() => {
    const storedEvents = getAllEvents();
    setEvents(storedEvents);
  }, []);

  const handleRegister = (eventId) => {
    const currentUser = getCurrentUser();

    if (!currentUser) {
      alert("Please login to register for events!");
      navigate("/login");
      return;
    }

    const registeredEvents = currentUser.registeredEvents || [];

    if (registeredEvents.includes(eventId)) {
      return alert("You have already registered for this event!");
    }

    registeredEvents.push(eventId);
    const updatedUser = { ...currentUser, registeredEvents };

    // ✅ participants + currentUser dono update honge
    updateCurrentUser(updatedUser);

    alert("Event registered successfully!");
    navigate("/participant/my-events");
  };

  // ✅ Search filter: first-letter or starting match
  const filteredEvents = events.filter((event) => {
    if (searchTerm.trim() === "") return true; // agar search empty hai to sab show karo
    const search = searchTerm.toLowerCase();
    return (
      event.name?.toLowerCase().startsWith(search) ||
      event.location?.toLowerCase().startsWith(search) ||
      event.description?.toLowerCase().startsWith(search)
    );
  });

  return (
    <>
      <Header />
      <main className="home-main">
        <section className="featured-events py-5">
          <div className="container">
            <h2 className="text-center mb-4">All Conferences</h2>

            {/* ✅ Search Bar */}
            <div className="mb-4 text-center">
              <input
  type="text"
  placeholder="Search events by name..."
  className="search-bar mx-auto mb-4 d-block"
  value={searchTerm}
  onChange={(e) => setSearchTerm(e.target.value)}
/>

            </div>

            <div className="row g-4">
              {filteredEvents.length > 0 ? (
                filteredEvents.map((event) => (
                  <div key={event.id} className="col-md-4">
                    <div className="card shadow-sm h-100">
                      <img
                        src={event.image}
                        alt={event.name}
                        className="card-img-top"
                      />
                      <div className="card-body d-flex flex-column">
                        <h5 className="card-title">{event.name}</h5>
                        <p className="card-text">
                          <strong>Date:</strong> {event.date} <br />
                          <strong>Location:</strong> {event.location || "Not specified"}
                        </p>
                        <p className="card-text text-muted">
                          {event.description || "No description available."}
                        </p>
                        <button
                          className="btn btn-primary mt-auto"
                          onClick={() => handleRegister(event.id)}
                        >
                          Register
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-center text-muted">No events found.</p>
              )}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
};

export default Conference;
