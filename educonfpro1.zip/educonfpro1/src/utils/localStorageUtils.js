// src/utils/LocalStorageUtils.js

// ---------- Participant Keys ----------
export const USERS_KEY = "participants";
export const CURRENT_USER_KEY = "currentUser";

// Participant Functions
export function getRegisteredUsers() {
  const users = localStorage.getItem(USERS_KEY);
  return users ? JSON.parse(users) : [];
}

export function saveRegisteredUsers(users) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

export function addRegisteredUser(user) {
  const users = getRegisteredUsers();

  // Check if email already exists (case-insensitive)
  const exists = users.some(u => u.email.toLowerCase() === user.email.toLowerCase());
  if (exists) return false;

  users.push(user);
  saveRegisteredUsers(users);
  return true;
}

export function findRegisteredUserByEmail(email) {
  return getRegisteredUsers().find(
    (user) => user.email.toLowerCase() === email.toLowerCase()
  );
}

export function authenticateUser(email, password) {
  const user = findRegisteredUserByEmail(email);
  if (user && user.password === password) return user;
  return null;
}

// ✅ Update user in participants list + session
export function updateCurrentUser(updatedUser) {
  // 1. Save current user session
  localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(updatedUser));

  // 2. Update participants list
  let users = getRegisteredUsers();
  users = users.map((u) =>
    u.email.toLowerCase() === updatedUser.email.toLowerCase() ? updatedUser : u
  );
  saveRegisteredUsers(users);
}

// Session handling
export function setCurrentUser(user) {
  localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
}

export function getCurrentUser() {
  const user = localStorage.getItem(CURRENT_USER_KEY);
  return user ? JSON.parse(user) : null;
}

export function logoutUser() {
  localStorage.removeItem(CURRENT_USER_KEY);
}

// ---------- Event Registration / Cancellation for Current User ----------

// Add event to current user's registeredEvents
export function registerEventForCurrentUser(eventId) {
  const user = getCurrentUser();
  if (!user) return false;

  user.registeredEvents = user.registeredEvents || [];
  if (!user.registeredEvents.includes(eventId)) {
    user.registeredEvents.push(eventId);
    updateCurrentUser(user);
    return true;
  }
  return false; // already registered
}

// Remove event from current user's registeredEvents
export function cancelEventForCurrentUser(eventId) {
  const user = getCurrentUser();
  if (!user) return false;

  user.registeredEvents = user.registeredEvents || [];
  user.registeredEvents = user.registeredEvents.filter((id) => id !== eventId);
  updateCurrentUser(user);
  return true;
}

// ---------- Admin Keys ----------
export const ADMIN_PROFILE_KEY = "adminProfile";
export const ADMIN_LOGGED_IN_KEY = "adminLoggedIn";

// Admin Functions
export function getAdminProfile() {
  const admin = localStorage.getItem(ADMIN_PROFILE_KEY);
  if (!admin) {
    // Default admin
    const defaultAdmin = {
      name: "Admin",
      email: "admin@educonfpro.com",
      password: "admin123"
    };
    localStorage.setItem(ADMIN_PROFILE_KEY, JSON.stringify(defaultAdmin));
    return defaultAdmin;
  }
  return JSON.parse(admin);
}

export function updateAdminProfile(admin) {
  localStorage.setItem(ADMIN_PROFILE_KEY, JSON.stringify(admin));
}

export function loginAdmin(email, password) {
  const admin = getAdminProfile();
  if (admin.email.toLowerCase() === email.toLowerCase() && admin.password === password) {
    localStorage.setItem(ADMIN_LOGGED_IN_KEY, "true");
    return true;
  }
  return false;
}

export function logoutAdmin() {
  localStorage.removeItem(ADMIN_LOGGED_IN_KEY);
}

export function isAdminLoggedIn() {
  return localStorage.getItem(ADMIN_LOGGED_IN_KEY) === "true";
}

// ---------- Events ----------
export const EVENTS_KEY = "allEvents";

export function getAllEvents() {
  const events = localStorage.getItem(EVENTS_KEY);
  return events ? JSON.parse(events) : [];
}

export function saveAllEvents(events) {
  localStorage.setItem(EVENTS_KEY, JSON.stringify(events));
}

export function addEvent(event) {
  const events = getAllEvents();
  events.push(event);
  saveAllEvents(events);
}

export function updateEvent(updatedEvent) {
  const events = getAllEvents().map((e) =>
    e.id === updatedEvent.id ? updatedEvent : e
  );
  saveAllEvents(events);
}

export function deleteEvent(eventId) {
  const events = getAllEvents().filter((e) => e.id !== eventId);
  saveAllEvents(events);
}
