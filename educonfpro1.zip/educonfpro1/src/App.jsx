import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

// ===== Public Pages =====
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import ForgotPassword from "./pages/ForgotPassword";
import Conference from "./event/Conference";

// ===== Participant Pages =====
import Pdash from "./pages/participant/Pdash"; 
import MyEvents from "./pages/participant/MyEvents"; 
import Profile from "./pages/participant/Profile"; 

// ===== Admin Pages =====
import AdminLogin from "./pages/admin/AdminLogin";
import AdminLayout from "./pages/admin/AdminLayout";
import AdminDashboard from "./pages/admin/AdminDashboard";
import EventManagement from "./pages/admin/EventManagement";
import ManageUser from "./pages/admin/ManageUser";
import Settings from "./pages/admin/Settings";

function AppWrapper() {
  return (
    <Router>
      <Routes>
        {/* ===== Public Pages ===== */}
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/conference" element={<Conference />} />

        {/* ===== Participant Panel ===== */}
        <Route path="/participant/dashboard" element={<Pdash />} />
        <Route path="/participant/my-events" element={<MyEvents />} />
        <Route path="/participant/profile" element={<Profile />} />

        {/* ===== Admin Panel ===== */}
        <Route path="/admin/login" element={<AdminLogin />} />

        {/* Admin layout with nested routes */}
        <Route path="/admin" element={<AdminLayout />}>
          <Route path="dashboard" element={<AdminDashboard />} />
          <Route path="event-management" element={<EventManagement />} />
          <Route path="manage-user" element={<ManageUser />} />
          <Route path="settings" element={<Settings />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default AppWrapper;
