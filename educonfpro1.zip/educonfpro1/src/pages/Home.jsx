// src/pages/Home.jsx
import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import Header from "./Header";
import Footer from "./Footer";
import "./Home.css";
import { getAllEvents } from "../utils/localStorageUtils";

const Home = () => {
  const location = useLocation();
  const [events, setEvents] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");

  // Scroll to section if needed
  useEffect(() => {
    if (location.state?.scrollTo) {
      const section = document.getElementById(location.state.scrollTo);
      section?.scrollIntoView({ behavior: "smooth" });
    }
  }, [location]);

  // Load events from localStorage
  useEffect(() => {
    const storedEvents = getAllEvents();
    setEvents(storedEvents);
  }, []);

  // Filter events based on search
  const filteredEvents = events.filter((event) =>
    event.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Handle Open button click
  const handleOpenClick = (eventName) => {
    alert(
      `If you want to register for "${eventName}", then go to the Events page.`
    );
  };

  return (
    <>
      <Header />
      <main className="home-main">
        {/* Welcome Section */}
        <section id="welcome" className="welcome-section text-center py-5">
          <div className="container">
            <h1 className="fw-bold text-primary mb-3">Welcome to EduConfPro</h1>
            <p className="text-muted mb-0">
              Your gateway to explore and participate in top-quality conferences,
              workshops, and seminars. Stay updated, learn, and grow!
            </p>
          </div>
        </section>

        {/* Featured Events Section */}
        <section id="events" className="featured-events py-5">
          <div className="container">
            <h2 className="text-center mb-4">Explore Featured Events</h2>

            {/* Search Bar */}
            <input
              type="text"
              placeholder="Search events by name..."
              className="search-bar mx-auto mb-4 d-block"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />

            <div className="row g-4">
              {filteredEvents.length > 0 ? (
                filteredEvents.map((event) => (
                  <div key={event.id} className="col-md-4">
                    <div className="card shadow-sm h-100">
                      <img
                        src={event.image}
                        className="card-img-top"
                        alt={event.name}
                      />
                      <div className="card-body text-center">
                        <h5 className="card-title">{event.name}</h5>
                        {/* ✅ Open button added */}
                        <button
                          className="btn btn-primary mt-2"
                          onClick={() => handleOpenClick(event.name)}
                        >
                          Open
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-center text-muted mt-3">No events found.</p>
              )}
            </div>
          </div>
        </section>

        {/* About Us Section */}
        <section id="about" className="about-us py-5 text-center">
          <div className="container">
            <h2 className="mb-4">About Us</h2>
            <p className="mb-0">
              EduConfPro brings together professionals, enthusiasts, and learners
              to participate in conferences, workshops, and seminars. We provide
              easy access to latest knowledge, networking, and hands-on
              experience.
            </p>
          </div>
        </section>

        {/* Contact Us Section */}
        <section id="contact" className="contact-us py-5 text-center">
          <div className="container">
            <h2 className="mb-4">Contact Us</h2>
            <p>
              Email: info@educonfpro.com | Phone: +91 12345 67890 | Address: 123
              Knowledge Street, Mumbai, India
            </p>
            <p>For queries, feel free to reach out anytime!</p>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
};

export default Home;
