// src/pages/participant/Profile.jsx
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Header from "../Header";
import Footer from "../Footer";
import { getCurrentUser, setCurrentUser } from "../../utils/localStorageUtils";
import "./Profile.css";

const Profile = () => {
  const navigate = useNavigate();
  const [profile, setProfile] = useState({
    fullName: "",
    email: "",
    contact: "",
    image: "",
    bio: "",
  });
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser) navigate("/login"); // redirect if not logged in

    if (currentUser) {
      setProfile({
        fullName: currentUser.fullName,
        email: currentUser.email,
        contact: currentUser.contact || "",
        image: currentUser.image || "",
        bio: currentUser.bio || "",
      });
    }
  }, [navigate]);

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (name === "image" && files && files[0]) {
      const reader = new FileReader();
      reader.onload = () => {
        setProfile((prev) => ({ ...prev, image: reader.result }));
      };
      reader.readAsDataURL(files[0]);
    } else {
      setProfile((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleSave = () => {
    const updatedUser = { ...getCurrentUser(), ...profile };
    setCurrentUser(updatedUser);

    // Update participants array
    const participants = JSON.parse(localStorage.getItem("participants")) || [];
    const updatedParticipants = participants.map((user) =>
      user.email === updatedUser.email ? updatedUser : user
    );
    localStorage.setItem("participants", JSON.stringify(updatedParticipants));

    setIsEditing(false);
    alert("Profile updated successfully!");
  };

  const handleRemoveProfile = () => {
    if (!window.confirm("Are you sure you want to remove your profile? This action cannot be undone.")) return;

    const participants = JSON.parse(localStorage.getItem("participants")) || [];
    const updatedParticipants = participants.filter(
      (user) => user.email !== profile.email
    );
    localStorage.setItem("participants", JSON.stringify(updatedParticipants));

    // Remove current user session
    localStorage.removeItem("currentUser");

    alert("Profile removed successfully!");
    navigate("/login"); // redirect to login after removal
  };

  const handleRemoveImage = () => {
    setProfile((prev) => ({ ...prev, image: "" }));
  };

  return (
    <>
      <Header />
      <main className="profile-main container py-5">
        <div className="profile-card card mx-auto shadow-sm p-4">
          {/* Profile Image */}
          <div className="profile-field mb-3 text-center">
            <div className="profile-img-container">
              {profile.image ? (
                <img src={profile.image} alt="Profile" className="profile-img" />
              ) : (
                <div className="profile-img-placeholder">No Image</div>
              )}
            </div>
            {isEditing && (
              <>
                <input type="file" name="image" accept="image/*" onChange={handleChange} />
                {profile.image && (
                  <button
                    className="btn btn-warning mt-2"
                    type="button"
                    onClick={handleRemoveImage}
                  >
                    Remove Profile Image
                  </button>
                )}
              </>
            )}
          </div>

          {/* Full Name */}
          <div className="profile-field mb-3">
            <label>Full Name:</label>
            {isEditing ? (
              <input type="text" name="fullName" value={profile.fullName} onChange={handleChange} />
            ) : (
              <p>{profile.fullName}</p>
            )}
          </div>

          {/* Email */}
          <div className="profile-field mb-3">
            <label>Email:</label>
            <p>{profile.email}</p>
          </div>

          {/* Contact */}
          <div className="profile-field mb-3">
            <label>Contact:</label>
            {isEditing ? (
              <input type="text" name="contact" value={profile.contact} onChange={handleChange} />
            ) : (
              <p>{profile.contact || "Not provided"}</p>
            )}
          </div>

          {/* Bio */}
          <div className="profile-field mb-3">
            <label>Bio:</label>
            {isEditing ? (
              <textarea
                name="bio"
                value={profile.bio}
                onChange={handleChange}
                placeholder="Write something about yourself"
                rows={3}
              />
            ) : (
              <p>{profile.bio || "No bio available"}</p>
            )}
          </div>

          {/* Buttons */}
          <div className="text-center mt-4">
            {isEditing ? (
              <>
                <button className="btn btn-success me-2" onClick={handleSave}>Save</button>
                <button className="btn btn-danger me-2" onClick={handleRemoveProfile}>Remove Profile</button>
              </>
            ) : (
              <button className="btn btn-primary" onClick={() => setIsEditing(true)}>Edit Profile</button>
            )}
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
};

export default Profile;
