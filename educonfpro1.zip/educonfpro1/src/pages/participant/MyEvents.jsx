// src/pages/participant/MyEvents.jsx
import React, { useEffect, useState } from "react";
import Header from "../Header";
import Footer from "../Footer";
import { getCurrentUser, setCurrentUser } from "../../utils/localStorageUtils";
import "./MyEvents.css";

const EVENT_KEY = "allEvents";

const MyEvents = () => {
  const [myEvents, setMyEvents] = useState([]);

  // Load registered events
  useEffect(() => {
    loadMyEvents();
  }, []);

  const loadMyEvents = () => {
    const currentUser = getCurrentUser();
    const savedEvents = JSON.parse(localStorage.getItem(EVENT_KEY)) || [];

    if (currentUser) {
      const registeredEventIds = currentUser.registeredEvents || [];
      const registeredEvents = savedEvents.filter((event) =>
        registeredEventIds.includes(event.id)
      );
      setMyEvents(registeredEvents);
    }
  };

  const handleCancelRegistration = (eventId) => {
    if (window.confirm("Are you sure you want to cancel your registration for this event?")) {
      const currentUser = getCurrentUser();
      if (!currentUser) return;

      // Remove event from user's registered events
      const updatedRegisteredEvents = currentUser.registeredEvents.filter(
        (id) => id !== eventId
      );
      currentUser.registeredEvents = updatedRegisteredEvents;
      setCurrentUser(currentUser);

      // Update state
      setMyEvents(myEvents.filter((event) => event.id !== eventId));
    }
  };

  return (
    <>
      <Header />

      <main className="my-events-main container py-5">
        <h1 className="mb-4 text-center">My Registered Events</h1>

        {myEvents.length === 0 ? (
          <p className="text-center">
            You have not registered for any events yet. Please go to{" "}
            <a href="/conference" className="text-primary">Events</a> to register.
          </p>
        ) : (
          <div className="row g-4">
            {myEvents.map((event) => (
              <div key={event.id} className="col-md-4">
                <div className="card shadow-sm h-100">
                  {event.image && (
                    <img
                      src={event.image}
                      alt={event.name}
                      className="card-img-top"
                      style={{ height: "160px", objectFit: "cover" }}
                    />
                  )}
                  <div className="card-body d-flex flex-column">
                    <h5 className="card-title">{event.name}</h5>
                    <p className="card-text">
                      <strong>Date:</strong> {event.date}
                    </p>
                    <p className="card-text">
                      <strong>Location:</strong> {event.location}
                    </p>
                    {event.description && (
                      <p className="card-text">{event.description}</p>
                    )}
                    <button
                      className="btn btn-danger mt-auto"
                      onClick={() => handleCancelRegistration(event.id)}
                    >
                      Cancel Registration
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      <Footer />
    </>
  );
};

export default MyEvents;
