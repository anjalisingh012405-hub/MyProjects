// src/pages/admin/AdminDashboard.jsx
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./AdminDashboard.css";

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [totalEvents, setTotalEvents] = useState(0);
  const [totalRegistrations, setTotalRegistrations] = useState(0);
  const [recentEvents, setRecentEvents] = useState([]);
  const [adminName, setAdminName] = useState("Admin");

  const EVENT_KEY = "allEvents";
  const SETTINGS_KEY = "adminProfile";

  const fetchData = () => {
    // ✅ Fetch all events
    const events = JSON.parse(localStorage.getItem(EVENT_KEY)) || [];
    setTotalEvents(events.length);

    // ✅ Sort events by date (newest first)
    const sortedEvents = events
      .filter((event) => event.date)
      .sort((a, b) => {
        const [d1, m1, y1] = a.date.split("-").map(Number);
        const [d2, m2, y2] = b.date.split("-").map(Number);

        const dateA = new Date(y1, m1 - 1, d1);
        const dateB = new Date(y2, m2 - 1, d2);

        return dateB - dateA; // newest → oldest
      });

    // ✅ Always keep latest 5 dynamically
    setRecentEvents(sortedEvents.slice(0, 5));

    // ✅ Fetch participants
    const participants = JSON.parse(localStorage.getItem("participants")) || [];
    setTotalRegistrations(participants.length);

    // ✅ Fetch admin name
    const profile =
      JSON.parse(localStorage.getItem(SETTINGS_KEY)) || { fullName: "Admin" };
    setAdminName(profile.fullName);
  };

  useEffect(() => {
    const loggedIn = JSON.parse(localStorage.getItem("adminLoggedIn"));
    if (!loggedIn) {
      navigate("/admin/login");
    }
    fetchData();

    // ✅ Update dynamically when localStorage changes
    window.addEventListener("storage", fetchData);
    return () => window.removeEventListener("storage", fetchData);
  }, [navigate]);

  return (
    <div className="admin-dashboard-main-content">
      <h1>Welcome, {adminName}!</h1>

      <div className="admin-dashboard-cards">
        <div
          className="dashboard-card clickable-card"
          onClick={() => navigate("/admin/event-management")}
        >
          <h2>Total Events</h2>
          <p className="card-count">{totalEvents}</p>
        </div>
        <div
          className="dashboard-card clickable-card"
          onClick={() => navigate("/admin/manage-user")}
        >
          <h2>Total Registrations</h2>
          <p className="card-count">{totalRegistrations}</p>
        </div>
      </div>

      <div className="recent-events">
        <h2>Recent Events</h2>
        <table className="recent-events-table">
          <thead>
            <tr>
              <th>Image</th>
              <th>Event Name</th>
              <th>Date</th>
              <th>Location</th>
              <th>Description</th>
            </tr>
          </thead>
          <tbody>
            {recentEvents.length === 0 ? (
              <tr>
                <td colSpan="5" className="text-center">
                  No events available
                </td>
              </tr>
            ) : (
              recentEvents.map((event) => (
                <tr key={event.id}>
                  <td>
                    {event.image ? (
                      <img
                        src={event.image}
                        alt={event.name}
                        style={{
                          width: "80px",
                          height: "50px",
                          objectFit: "cover",
                          borderRadius: "4px",
                        }}
                      />
                    ) : (
                      <span>No Image</span>
                    )}
                  </td>
                  <td>{event.name}</td>
                  <td>{event.date}</td>
                  <td>{event.location || "Not specified"}</td>
                  <td>{event.description || "No description"}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminDashboard;
