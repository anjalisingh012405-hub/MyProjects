// src/pages/admin/ManageUser.jsx
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./ManageUser.css";

const PARTICIPANTS_KEY = "participants";

const ManageUser = () => {
  const navigate = useNavigate();
  const [participants, setParticipants] = useState([]);
  const [form, setForm] = useState({ email: "", fullName: "", contact: "" });
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    const loggedIn = JSON.parse(localStorage.getItem("adminLoggedIn"));
    if (!loggedIn) navigate("/admin/login");

    const savedParticipants = JSON.parse(localStorage.getItem(PARTICIPANTS_KEY)) || [];
    setParticipants(savedParticipants);
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.email || !form.fullName) return alert("Full Name and Email are required!");

    let updatedParticipants = [...participants];

    if (isEditing) {
      // Update existing participant
      updatedParticipants = updatedParticipants.map((p) =>
        p.email === form.email ? { ...p, ...form } : p
      );
      setIsEditing(false);
    } else {
      // Add new participant (if not exists)
      const exists = participants.find(p => p.email === form.email);
      if (exists) return alert("Participant with this email already exists!");
      updatedParticipants.push(form);
    }

    setParticipants(updatedParticipants);
    localStorage.setItem(PARTICIPANTS_KEY, JSON.stringify(updatedParticipants));
    setForm({ email: "", fullName: "", contact: "" });
  };

  const handleEdit = (participant) => {
    setForm(participant);
    setIsEditing(true);
  };

  const handleDelete = (email) => {
    if (!window.confirm("Are you sure you want to delete this participant?")) return;
    const filtered = participants.filter((p) => p.email !== email);
    setParticipants(filtered);
    localStorage.setItem(PARTICIPANTS_KEY, JSON.stringify(filtered));
  };

  return (
    <div className="manage-user-wrapper">
      <h1>Manage Participants</h1>

      <form onSubmit={handleSubmit} className="participant-form">
        <input
          type="text"
          name="fullName"
          placeholder="Full Name"
          value={form.fullName}
          onChange={handleChange}
          required
        />
        <input
          type="email"
          name="email"
          placeholder="Email"
          value={form.email}
          onChange={handleChange}
          required
          disabled={isEditing}
        />
        <input
          type="text"
          name="contact"
          placeholder="Contact"
          value={form.contact}
          onChange={handleChange}
        />
        <button type="submit">{isEditing ? "Update Participant" : "Add Participant"}</button>
      </form>

      <h2>All Participants</h2>
      <table className="participant-table">
        <thead>
          <tr>
            <th>Full Name</th>
            <th>Email</th>
            <th>Contact</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {participants.length === 0 ? (
            <tr>
              <td colSpan="4" className="text-center">No participants found</td>
            </tr>
          ) : (
            participants.map((p) => (
              <tr key={p.email}>
                <td>{p.fullName}</td>
                <td>{p.email}</td>
                <td>{p.contact}</td>
                <td>
                  <button onClick={() => handleEdit(p)}>Edit</button>
                  <button onClick={() => handleDelete(p.email)}>Delete</button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default ManageUser;
