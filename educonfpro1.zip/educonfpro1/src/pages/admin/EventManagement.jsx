// src/pages/admin/EventManagement.jsx
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./EventManagement.css";

const EVENT_KEY = "allEvents";

const EventManagement = () => {
  const navigate = useNavigate();
  const [events, setEvents] = useState([]);
  const [form, setForm] = useState({
    id: null,
    image: "",
    name: "",
    date: "",
    description: "",
    location: "",
  });
  const [isEditing, setIsEditing] = useState(false);

  // ✅ Helper: sort newest → oldest
  const sortEvents = (arr) => {
    return arr.sort((a, b) => {
      if (!a.date || !b.date) return 0;
      return new Date(b.date) - new Date(a.date);
    });
  };

  useEffect(() => {
    const loggedIn = JSON.parse(localStorage.getItem("adminLoggedIn"));
    if (!loggedIn) navigate("/admin/login");

    const savedEvents = JSON.parse(localStorage.getItem(EVENT_KEY)) || [];
    setEvents(sortEvents(savedEvents));
  }, [navigate]);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => setForm({ ...form, image: reader.result });
    reader.readAsDataURL(file);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.name || !form.date || !form.image || !form.location) {
      return alert("All fields are required!");
    }

    let updatedEvents = [...events];

    if (isEditing) {
      updatedEvents = updatedEvents.map((ev) =>
        ev.id === form.id ? { ...ev, ...form } : ev
      );
      setIsEditing(false);
    } else {
      const newEvent = { ...form, id: Date.now() };
      updatedEvents.push(newEvent);
    }

    updatedEvents = sortEvents(updatedEvents);

    setEvents(updatedEvents);
    localStorage.setItem(EVENT_KEY, JSON.stringify(updatedEvents));

    setForm({
      id: null,
      image: "",
      name: "",
      date: "",
      description: "",
      location: "",
    });
  };

  const handleEdit = (event) => {
    setForm({ ...event });
    setIsEditing(true);
  };

  const handleDelete = (id) => {
    if (!window.confirm("Are you sure you want to delete this event?")) return;
    const filtered = events.filter((ev) => ev.id !== id);
    setEvents(filtered);
    localStorage.setItem(EVENT_KEY, JSON.stringify(filtered));
  };

  return (
    <div className="event-management-wrapper">
      <h1>Event Management</h1>

      <div className="event-form-wrapper">
        <form onSubmit={handleSubmit} className="event-form">
          <label>
            Event Image :
            <input
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              required={!isEditing && !form.image}
            />
          </label>
          {form.image && (
            <img
              src={form.image}
              alt="Preview"
              style={{
                width: "100px",
                height: "60px",
                marginTop: "10px",
                objectFit: "cover",
                display: "block",
              }}
            />
          )}

          <label>
            Event Name :
            <input
              type="text"
              name="name"
              placeholder="Enter event name"
              value={form.name}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            Event Date :
            <input
              type="date"
              name="date"
              value={form.date}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            Description :
            <textarea
              name="description"
              placeholder="Enter event description"
              value={form.description}
              onChange={handleChange}
            />
          </label>

          <label>
            Location :
            <input
              type="text"
              name="location"
              placeholder="Enter location"
              value={form.location}
              onChange={handleChange}
              required
            />
          </label>

          <button type="submit">
            {isEditing ? "Update Event" : "Add Event"}
          </button>
        </form>
      </div>

      <h2 className="all-events-title">All Events</h2>

      <div className="event-table-wrapper">
        <table className="event-table">
          <thead>
            <tr>
              <th>Image</th>
              <th>Name</th>
              <th>Date</th>
              <th>Description</th>
              <th>Location</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {events.length === 0 ? (
              <tr>
                <td colSpan="6" className="text-center">
                  No events available
                </td>
              </tr>
            ) : (
              events.map((ev) => (
                <tr key={ev.id}>
                  <td>
                    <img
                      src={ev.image}
                      alt={ev.name}
                      style={{
                        width: "80px",
                        height: "50px",
                        objectFit: "cover",
                      }}
                    />
                  </td>
                  <td>{ev.name}</td>
                  <td>{ev.date}</td>
                  <td>{ev.description}</td>
                  <td>{ev.location}</td>
                  <td>
                    <button onClick={() => handleEdit(ev)}>Edit</button>
                    <button onClick={() => handleDelete(ev.id)}>Delete</button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default EventManagement;
