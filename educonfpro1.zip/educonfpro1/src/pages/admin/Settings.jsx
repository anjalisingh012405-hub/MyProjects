// src/pages/admin/Settings.jsx
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./Settings.css";

const SETTINGS_KEY = "adminProfile";

const Settings = () => {
  const navigate = useNavigate();
  const [profile, setProfile] = useState({ fullName: "", email: "", password: "" });

  useEffect(() => {
    const loggedIn = JSON.parse(localStorage.getItem("adminLoggedIn"));
    if (!loggedIn) navigate("/admin/login");

    const savedProfile = JSON.parse(localStorage.getItem(SETTINGS_KEY)) || {
      fullName: "Admin",
      email: "admin@example.com",
      password: "admin123",
    };
    setProfile(savedProfile);
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(savedProfile)); // ensure default saved
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setProfile({ ...profile, [name]: value });
  };

  const handleSave = () => {
    if (!profile.fullName || !profile.email || !profile.password) {
      return alert("All fields are required!");
    }

    // Save profile to localStorage
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(profile));

    // Trigger a custom event so other components (like Dashboard) can listen and update name
    window.dispatchEvent(new Event("storage"));

    alert("Profile updated successfully!");
  };

  return (
    <div className="settings-wrapper">
      <h1>Admin Settings</h1>
      <div className="settings-form">
        <label>Full Name:</label>
        <input
          type="text"
          name="fullName"
          value={profile.fullName}
          onChange={handleChange}
        />

        <label>Email:</label>
        <input
          type="email"
          name="email"
          value={profile.email}
          onChange={handleChange}
        />

        <label>Password:</label>
        <input
          type="password"
          name="password"
          value={profile.password}
          onChange={handleChange}
        />

        <button onClick={handleSave}>Save Changes</button>
      </div>
    </div>
  );
};

export default Settings;
