// src/utils/LocalStorageUtils.js

// ---------- Participant Keys ----------
export const USERS_KEY = "participants";
export const CURRENT_USER_KEY = "currentUser";

// Participant Functions
export function getRegisteredUsers() {
  const users = localStorage.getItem(USERS_KEY);
  return users ? JSON.parse(users) : [];
}

export function saveRegisteredUsers(users) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

export function addRegisteredUser(user) {
  const users = getRegisteredUsers();
  users.push(user);
  saveRegisteredUsers(users);
  return true;
}

export function findRegisteredUserByEmail(email) {
  return getRegisteredUsers().find((user) => user.email === email);
}

export function authenticateUser(email, password) {
  const user = findRegisteredUserByEmail(email);
  if (user && user.password === password) return user;
  return null;
}

// Session handling
export function setCurrentUser(user) {
  localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
}

export function getCurrentUser() {
  return JSON.parse(localStorage.getItem(CURRENT_USER_KEY));
}

export function logoutUser() {
  localStorage.removeItem(CURRENT_USER_KEY);
}

// ---------- Admin Keys ----------
export const ADMIN_PROFILE_KEY = "adminProfile";
export const ADMIN_LOGGED_IN_KEY = "adminLoggedIn";

// Admin Functions
export function getAdminProfile() {
  const admin = localStorage.getItem(ADMIN_PROFILE_KEY);
  if (!admin) {
    // Default admin
    const defaultAdmin = { name: "Admin", email: "admin@educonfpro.com", password: "admin123" };
    localStorage.setItem(ADMIN_PROFILE_KEY, JSON.stringify(defaultAdmin));
    return defaultAdmin;
  }
  return JSON.parse(admin);
}

export function updateAdminProfile(admin) {
  localStorage.setItem(ADMIN_PROFILE_KEY, JSON.stringify(admin));
}

export function loginAdmin(email, password) {
  const admin = getAdminProfile();
  if (admin.email === email && admin.password === password) {
    localStorage.setItem(ADMIN_LOGGED_IN_KEY, "true");
    return true;
  }
  return false;
}

export function logoutAdmin() {
  localStorage.removeItem(ADMIN_LOGGED_IN_KEY);
}

export function isAdminLoggedIn() {
  return localStorage.getItem(ADMIN_LOGGED_IN_KEY) === "true";
}

// ---------- Events ----------
export const EVENTS_KEY = "allEvents";

export function getAllEvents() {
  const events = localStorage.getItem(EVENTS_KEY);
  return events ? JSON.parse(events) : [];
}

export function saveAllEvents(events) {
  localStorage.setItem(EVENTS_KEY, JSON.stringify(events));
}

export function addEvent(event) {
  const events = getAllEvents();
  events.push(event);
  saveAllEvents(events);
}

export function updateEvent(updatedEvent) {
  const events = getAllEvents().map(e => e.id === updatedEvent.id ? updatedEvent : e);
  saveAllEvents(events);
}

export function deleteEvent(eventId) {
  const events = getAllEvents().filter(e => e.id !== eventId);
  saveAllEvents(events);
}
