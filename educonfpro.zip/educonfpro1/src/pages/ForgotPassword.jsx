import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import Header from "./Header";
import Footer from "./Footer";
import "./Login.css"; // reuse login CSS

const ForgotPassword = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");

  const handleForgot = (e) => {
    e.preventDefault();
    const users = JSON.parse(localStorage.getItem("participants")) || [];
    const user = users.find((u) => u.email === email);

    if (user) {
      alert(`Your password is: ${user.password}`);
    } else {
      alert("Email not registered!");
    }
  };

  return (
    <>
      <Header />
      <div className="auth-wrapper">
        <main className="login-main">
          <h2>Forgot Password</h2>
          <form onSubmit={handleForgot} className="login-form">
            <input
              type="email"
              placeholder="Enter your registered email"
              value={email}
              required
              onChange={(e) => setEmail(e.target.value)}
            />
            <button type="submit">Get Password</button>
          </form>

          <button
            className="btn-back-login"
            onClick={() => navigate("/login")}
          >
            Back to Login
          </button>
        </main>
      </div>
      <Footer />
    </>
  );
};

export default ForgotPassword;
