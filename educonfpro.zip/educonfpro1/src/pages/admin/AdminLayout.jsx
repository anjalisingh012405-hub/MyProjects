// src/pages/admin/AdminLayout.jsx
import React from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import "./AdminLayout.css";

const AdminLayout = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("adminLoggedIn");
    navigate("/admin/login");
  };

  return (
    <div className="admin-layout-wrapper">
      {/* Sidebar */}
      <nav className="admin-sidebar">
        <h2>EduConfPro</h2>
        <NavLink to="/admin/dashboard">Dashboard</NavLink>
        <NavLink to="/admin/event-management">Event Management</NavLink>
        <NavLink to="/admin/manage-user">Manage Users</NavLink>
        <NavLink to="/admin/settings">Settings</NavLink>
        <button className="btn-logout" onClick={handleLogout}>Logout</button>
      </nav>

      {/* Main Content */}
      <main className="admin-content">
        <Outlet /> {/* Ye right side ka content render karega */}
      </main>
    </div>
  );
};

export default AdminLayout;
