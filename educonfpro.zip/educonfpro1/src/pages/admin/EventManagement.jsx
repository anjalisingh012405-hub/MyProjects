// src/pages/admin/EventManagement.jsx
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./EventManagement.css";

const EVENT_KEY = "allEvents";

const EventManagement = () => {
  const navigate = useNavigate();
  const [events, setEvents] = useState([]);
  const [form, setForm] = useState({ id: null, name: "", date: "", description: "" });
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    const loggedIn = JSON.parse(localStorage.getItem("adminLoggedIn"));
    if (!loggedIn) navigate("/admin/login");

    const savedEvents = JSON.parse(localStorage.getItem(EVENT_KEY)) || [];
    setEvents(savedEvents);
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.name || !form.date) return alert("Name and Date are required!");

    let updatedEvents = [...events];

    if (isEditing) {
      // Update existing event
      updatedEvents = updatedEvents.map((ev) =>
        ev.id === form.id ? { ...ev, ...form } : ev
      );
      setIsEditing(false);
    } else {
      // Add new event
      const newEvent = { ...form, id: Date.now() };
      updatedEvents.push(newEvent);
    }

    setEvents(updatedEvents);
    localStorage.setItem(EVENT_KEY, JSON.stringify(updatedEvents));
    setForm({ id: null, name: "", date: "", description: "" });
  };

  const handleEdit = (event) => {
    setForm(event);
    setIsEditing(true);
  };

  const handleDelete = (id) => {
    if (!window.confirm("Are you sure you want to delete this event?")) return;
    const filtered = events.filter((ev) => ev.id !== id);
    setEvents(filtered);
    localStorage.setItem(EVENT_KEY, JSON.stringify(filtered));
  };

  return (
   <div className="event-management-wrapper">
  <h1>Event Management</h1>

  {/* Centered Form */}
  <div className="event-form-wrapper">
    <form onSubmit={handleSubmit} className="event-form">
      <input
        type="text"
        name="name"
        placeholder="Event Name"
        value={form.name}
        onChange={handleChange}
        required
      />
      <input
        type="date"
        name="date"
        value={form.date}
        onChange={handleChange}
        required
      />
      <textarea
        name="description"
        placeholder="Description"
        value={form.description}
        onChange={handleChange}
      />
      <button type="submit">{isEditing ? "Update Event" : "Add Event"}</button>
    </form>
  </div>

  <h2 className="all-events-title">All Events</h2>

  {/* Centered Table */}
  <div className="event-table-wrapper">
    <table className="event-table">
      <thead>
        <tr>
          <th>Name</th>
          <th>Date</th>
          <th>Description</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {events.length === 0 ? (
          <tr>
            <td colSpan="4" className="text-center">No events available</td>
          </tr>
        ) : (
          events.map((ev) => (
            <tr key={ev.id}>
              <td>{ev.name}</td>
              <td>{ev.date}</td>
              <td>{ev.description}</td>
              <td>
                <button onClick={() => handleEdit(ev)}>Edit</button>
                <button onClick={() => handleDelete(ev.id)}>Delete</button>
              </td>
            </tr>
          ))
        )}
      </tbody>
    </table>
  </div>
</div>

  );
};

export default EventManagement;
