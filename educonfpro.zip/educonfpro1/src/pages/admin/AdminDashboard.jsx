// src/pages/admin/AdminDashboard.jsx
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./AdminDashboard.css";

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [totalEvents, setTotalEvents] = useState(0);
  const [totalRegistrations, setTotalRegistrations] = useState(0);
  const [recentEvents, setRecentEvents] = useState([]);
  const [adminName, setAdminName] = useState("Admin"); // <-- Dynamic admin name

  const EVENT_KEY = "allEvents"; // same key as EventManagement
  const SETTINGS_KEY = "adminProfile"; // admin profile key

  const fetchData = () => {
    // Fetch events
    const events = JSON.parse(localStorage.getItem(EVENT_KEY)) || [];
    setTotalEvents(events.length);
    setRecentEvents(events.slice(-5).reverse()); // last 5 events, newest first

    // Fetch participants
    const participants = JSON.parse(localStorage.getItem("participants")) || [];
    setTotalRegistrations(participants.length);

    // Fetch admin name
    const profile = JSON.parse(localStorage.getItem(SETTINGS_KEY)) || { fullName: "Admin" };
    setAdminName(profile.fullName);
  };

  useEffect(() => {
    const loggedIn = JSON.parse(localStorage.getItem("adminLoggedIn"));
    if (!loggedIn) {
      navigate("/admin/login");
    }
    fetchData();

    // Listen for storage changes (update dashboard if events or profile change)
    window.addEventListener("storage", fetchData);
    return () => window.removeEventListener("storage", fetchData);
  }, [navigate]);

  return (
    <div className="admin-dashboard-main-content">
      <h1>Welcome, {adminName}!</h1>

      <div className="admin-dashboard-cards">
        <div className="dashboard-card">
          <h2>Total Events</h2>
          <p className="card-count">{totalEvents}</p>
        </div>
        <div className="dashboard-card">
          <h2>Total Registrations</h2>
          <p className="card-count">{totalRegistrations}</p>
        </div>
      </div>

      <div className="recent-events">
        <h2>Recent Events</h2>
        <table className="recent-events-table">
          <thead>
            <tr>
              <th>Event Name</th>
              <th>Date</th>
              <th>Description</th>
            </tr>
          </thead>
          <tbody>
            {recentEvents.length === 0 ? (
              <tr>
                <td colSpan="3" className="text-center">No recent events</td>
              </tr>
            ) : (
              recentEvents.map((event) => (
                <tr key={event.id}>
                  <td>{event.name}</td>
                  <td>{event.date}</td>
                  <td>{event.description}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminDashboard;
