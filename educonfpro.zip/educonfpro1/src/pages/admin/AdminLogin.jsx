// src/pages/admin/AdminLogin.jsx
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./AdminLogin.css";

// Keys for admin session & credentials
const ADMIN_KEY = "adminLoggedIn";
const DEFAULT_ADMIN = { email: "admin@educonfpro.com", password: "admin123", name: "Admin" };

const AdminLogin = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false); // ✅ Eye icon toggle

  // Auto-redirect if already logged in
  useEffect(() => {
    const loggedIn = JSON.parse(localStorage.getItem(ADMIN_KEY));
    if (loggedIn) {
      navigate("/admin/dashboard");
    }
  }, [navigate]);

  const handleLogin = (e) => {
    e.preventDefault();

    if (!email || !password) return alert("All fields are required!");

    // Check credentials (default admin)
    if (email === DEFAULT_ADMIN.email && password === DEFAULT_ADMIN.password) {
      localStorage.setItem(ADMIN_KEY, "true");
      localStorage.setItem("adminProfile", JSON.stringify(DEFAULT_ADMIN));
      navigate("/admin/dashboard");
    } else {
      alert("Invalid Email or Password");
    }
  };

  return (
    <div className="admin-login-wrapper">
      <main className="admin-login-main">
        <h2>Admin Login</h2>
        <form onSubmit={handleLogin} className="admin-login-form">
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />

          {/* Password field with eye icon */}
          <div className="password-field">
            <input
              type={showPassword ? "text" : "password"}
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <span
              className="toggle-password"
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? "🙈" : "👁️"}
            </span>
          </div>

          <button type="submit">Login</button>
        </form>
      </main>
    </div>
  );
};

export default AdminLogin;
