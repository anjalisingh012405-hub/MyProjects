// src/pages/Register.jsx
import React, { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import Header from "./Header";
import Footer from "./Footer";
import { addRegisteredUser, getCurrentUser } from "../utils/LocalStorageUtils";
import "./Register.css";

const Register = () => {
  const navigate = useNavigate();
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [contact, setContact] = useState("");
  const [gender, setGender] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  useEffect(() => {
    // If already logged in, redirect to dashboard
    const currentUser = getCurrentUser();
    if (currentUser) navigate("/participant/dashboard");
  }, []);

  const handleRegister = (e) => {
    e.preventDefault();

    if (!fullName || !email || !contact || !gender || !password || !confirmPassword) {
      return alert("All fields are required!");
    }
    if (password !== confirmPassword) return alert("Passwords do not match!");
    if (!/^\S+@\S+\.\S+$/.test(email)) return alert("Invalid email format!");
    if (!/^\d{10}$/.test(contact)) return alert("Contact number must be 10 digits!");

    const newUser = { fullName, email, contact, gender, password };
    const added = addRegisteredUser(newUser);

    if (!added) return alert("Email already registered!");

    alert("Registration successful! Please login.");
    navigate("/login");
  };

  return (
    <>
      <Header />
      <div className="register-wrapper">
        <main className="register-main">
          <h2>Participant Registration</h2>
          <form onSubmit={handleRegister} className="register-form">
            <input type="text" placeholder="Full Name" value={fullName} onChange={e => setFullName(e.target.value)} required />
            <input type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} required />
            <input type="text" placeholder="Contact Number" value={contact} onChange={e => setContact(e.target.value)} required />
            <div className="gender-container">
              <label><input type="radio" value="Male" checked={gender === "Male"} onChange={e => setGender(e.target.value)} /> Male</label>
              <label><input type="radio" value="Female" checked={gender === "Female"} onChange={e => setGender(e.target.value)} /> Female</label>
              <label><input type="radio" value="Other" checked={gender === "Other"} onChange={e => setGender(e.target.value)} /> Other</label>
            </div>

            {/* Password field with eye icon */}
            <div className="password-field">
              <input
                type={showPassword ? "text" : "password"}
                placeholder="Password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                required
              />
              <span className="toggle-password" onClick={() => setShowPassword(!showPassword)}>
                {showPassword ? "🙈" : "👁️"}
              </span>
            </div>

            {/* Confirm Password field with eye icon */}
            <div className="password-field">
              <input
                type={showConfirmPassword ? "text" : "password"}
                placeholder="Confirm Password"
                value={confirmPassword}
                onChange={e => setConfirmPassword(e.target.value)}
                required
              />
              <span className="toggle-password" onClick={() => setShowConfirmPassword(!showConfirmPassword)}>
                {showConfirmPassword ? "🙈" : "👁️"}
              </span>
            </div>

            <button type="submit">Register</button>
          </form>
          <div className="register-links-box">
            Already have an account? <Link to="/login">Login</Link>
          </div>
        </main>
      </div>
      <Footer />
    </>
  );
};

export default Register;
