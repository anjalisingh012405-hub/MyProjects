// src/pages/Login.jsx
import React, { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import Header from "./Header";
import Footer from "./Footer";
import { authenticateUser, setCurrentUser, getCurrentUser } from "../utils/LocalStorageUtils";
import "./Login.css";

const Login = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false); // ✅ UI only
  const [showPassword, setShowPassword] = useState(false); // ✅ For eye icon toggle

  useEffect(() => {
    const currentUser = getCurrentUser();
    if (currentUser) navigate("/participant/dashboard");
  }, [navigate]);

  const handleLogin = (e) => {
    e.preventDefault();
    if (!email || !password) return alert("All fields are required");

    const user = authenticateUser(email, password);
    if (!user) return alert("Invalid Email or Password");

    setCurrentUser(user);
    navigate("/participant/dashboard");
  };

  return (
    <>
      <Header />
      <div className="login-wrapper">
        <main className="login-main">
          <h2>Participant Login</h2>
          <form onSubmit={handleLogin} className="login-form">
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
            />

            <div className="password-field">
              <input
                type={showPassword ? "text" : "password"}
                placeholder="Password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                required
              />
              <span
                className="toggle-password"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? "🙈" : "👁️"}
              </span>
            </div>

            {/* ✅ Remember Me checkbox UI only */}
            <div className="remember-container">
              <input
                type="checkbox"
                id="rememberMe"
                checked={rememberMe}
                onChange={e => setRememberMe(e.target.checked)}
              />
              <label htmlFor="rememberMe">Remember Me</label>
            </div>

            <button type="submit">Login</button>
          </form>

          {/* ✅ Forgot Password link above registration link */}
          <div className="login-links-box">
            <Link to="/forgot-password">Forgot Password?</Link>
          </div>
          <div className="login-links-box">
            <Link to="/register">Haven’t Registered Yet?</Link>
          </div>
        </main>
      </div>
      <Footer />
    </>
  );
};

export default Login;
