// src/pages/Home.jsx
import React, { useEffect } from "react";
import { useLocation } from "react-router-dom";
import Header from "./Header";
import Footer from "./Footer";
import "./Home.css";

const Home = () => {
  const location = useLocation();

  // Scroll logic
  useEffect(() => {
    if (location.state?.scrollTo) {
      const section = document.getElementById(location.state.scrollTo);
      section?.scrollIntoView({ behavior: "smooth" });
    }
  }, [location]);

  const featuredEvents = [
    { id: 1, name: "React Conference 2025", image: "https://tse1.mm.bing.net/th/id/OIP.dW3jXUKtul4DSWOa-IdCNgHaEK?pid=Api&P=0&h=220" },
    { id: 2, name: "AI & ML Workshop", image: "https://erode-sengunthar.ac.in/wp-content/uploads/2024/02/aiml-image-1.png" },
    { id: 3, name: "Cyber Security Seminar", image: "https://tse2.mm.bing.net/th/id/OIP.2-GVl506xGrCbw_qYX0kBQHaDq?pid=Api&P=0&h=220" },
    { id: 4, name: "Data Science Meetup", image: "https://tse2.mm.bing.net/th/id/OIP.FMvBDoSKPl55TBG1e_G6PAHaEo?pid=Api&P=0&h=220" },
    { id: 5, name: "Cloud Computing Workshop", image: "https://propernewstime.com/wp-content/uploads/2023/01/Cloud-Computing.jpeg" },
    { id: 6, name: "Blockchain Conference", image: "https://tse4.mm.bing.net/th/id/OIP.2gfNnQca9lq-Qxf1Q_m4PQHaEJ?pid=Api&P=0&h=220" },
    { id: 7, name: "IoT Seminar", image: "https://static.vecteezy.com/system/resources/previews/012/742/295/large_2x/abstract-internet-of-things-concept-city-5g-iot-internet-of-things-communication-network-innovation-technology-concept-icons-connect-wireless-devices-and-networking-innovation-technology-vector.jpg" },
    { id: 8, name: "DevOps Workshop", image: "https://www.edureka.co/blog/wp-content/uploads/2019/06/DevOps.png" },
    { id: 9, name: "Python Bootcamp", image: "https://moodle.sdcollegeambala.org/pluginfile.php/191514/course/overviewfiles/python%20bootcamp.jpg" },
  { id: 10, name: "Kubernetes Meetup", image: "https://tse1.mm.bing.net/th/id/OIP.DSvseXIXuqTHN4PNefIVyAHaEt?pid=Api&P=0&h=220" },
  { id: 11, name: "Frontend Dev Summit", image: "https://tse3.mm.bing.net/th/id/OIP.nIwCkshJRg4E_SaoZwAgUAHaD3?pid=Api&P=0&h=220" },
  { id: 12, name: "Agile & Scrum Workshop", image: "https://kruschecompany.com/wp-content/uploads/2021/09/Agile-software-development-with-Scrum-blog-cover-image.jpg" },

  ];

  const handleOpen = (eventName) => {
    alert(`If you want to register for "${eventName}", please go to the Events section.`);
  };

  return (
    <>
      <Header />
      <main className="home-main">
        {/* Welcome Section */}
        <section id="welcome" className="welcome-section text-center py-5">
          <div className="container">
            <h1 className="fw-bold text-primary mb-3">Welcome to EduConfPro</h1>
            <p className="text-muted mb-0">
              Your gateway to explore and participate in top-quality conferences, workshops, and seminars. Stay updated, learn, and grow!
            </p>
          </div>
        </section>

        {/* Featured Events Section */}
        <section id="events" className="featured-events py-5">
          <div className="container">
            <h2 className="text-center mb-4">Explore Featured Events</h2>
            <div className="row g-4">
              {featuredEvents.map((event) => (
                <div key={event.id} className="col">
                  <div className="card shadow-sm h-100">
                    <img src={event.image} className="card-img-top" alt={event.name} />
                    <div className="card-body d-flex flex-column">
                      <h5 className="card-title">{event.name}</h5>
                      <button onClick={() => handleOpen(event.name)} className="btn btn-primary mt-auto">Open</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* About Us Section */}
        <section id="about" className="about-us py-5 text-center">
          <div className="container">
            <h2 className="mb-4">About Us</h2>
            <p className="mb-0">
              EduConfPro brings together professionals, enthusiasts, and learners to participate in conferences, workshops, and seminars. We provide easy access to latest knowledge, networking, and hands-on experience.
            </p>
          </div>
        </section>

        {/* Contact Us Section */}
        <section id="contact" className="contact-us py-5 text-center">
          <div className="container">
            <h2 className="mb-4">Contact Us</h2>
            <p>Email: info@educonfpro.com | Phone: +91 12345 67890 | Address: 123 Knowledge Street, Mumbai, India</p>
            <p>For queries, feel free to reach out anytime!</p>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
};

export default Home;
