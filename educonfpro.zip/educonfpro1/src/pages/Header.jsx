// src/pages/Header.jsx
import React from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import "./Header.css";
import { getCurrentUser, logoutUser } from "../utils/LocalStorageUtils";

const Header = () => {
  const navigate = useNavigate();
  const location = useLocation(); // ✅ Current location
  const currentUser = getCurrentUser(); // ✅ Use LocalStorageUtils

  const handleLogout = () => {
    logoutUser(); // ✅ Clears CURRENT_USER_KEY only
    navigate("/"); // Redirect to home
  };

  const scrollToSection = (id, e) => {
    e.preventDefault();

    // If not on Home page, first navigate to Home and then scroll
    if (location.pathname !== "/") {
      navigate("/", { state: { scrollTo: id } });
    } else {
      const section = document.getElementById(id);
      section?.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <header className="header navbar d-flex align-items-center justify-content-between px-4 py-3">
      {/* Logo */}
      <h1 className="navbar-brand">EduConfPro</h1>

      {/* Navigation */}
      <nav className="navbar-nav d-flex align-items-center gap-3">
        {!currentUser && (
          <>
            <Link className="nav-link" to="/" onClick={(e) => scrollToSection("welcome", e)}>Home</Link>
            <Link className="nav-link" to="/conference">Events</Link>
            <Link className="nav-link" to="/" onClick={(e) => scrollToSection("about", e)}>About</Link>
            <Link className="nav-link" to="/" onClick={(e) => scrollToSection("contact", e)}>Contact</Link>
          </>
        )}

        {currentUser && (
          <>
            <Link className="nav-link" to="/">Home</Link>
            <Link className="nav-link" to="/conference">Events</Link>
            <Link className="nav-link" to="/participant/dashboard">Dashboard</Link>
            <Link className="nav-link" to="/participant/profile">Profile</Link>
          </>
        )}
      </nav>

      {/* Right buttons */}
      <div>
        {!currentUser && <Link className="btn btn-light" to="/login">Get Started</Link>}
        {currentUser && (
          <button className="btn btn-light" onClick={handleLogout}>Logout</button>
        )}
      </div>
    </header>
  );
};

export default Header;
