// src/pages/participant/MyEvents.jsx
import React, { useEffect, useState } from "react";
import Header from "../Header";
import Footer from "../Footer";
import { getCurrentUser } from "../../utils/LocalStorageUtils";
import "./MyEvents.css";

const MyEvents = () => {
  const [myEvents, setMyEvents] = useState([]);

  // Sample event data (same as Conference.jsx)
  const allEvents = [
    { id: 1, name: "React Conference 2025", date: "2025-12-01" },
    { id: 2, name: "AI & ML Workshop", date: "2025-11-20" },
    { id: 3, name: "Cyber Security Seminar", date: "2025-10-15" },
  ];

  useEffect(() => {
    const currentUser = getCurrentUser();

    if (currentUser) {
      const registeredEventIds = currentUser.registeredEvents || [];
      const registeredEvents = allEvents.filter(event =>
        registeredEventIds.includes(event.id)
      );
      setMyEvents(registeredEvents);
    }
  }, []);

  return (
    <>
      <Header />

      <main className="my-events-main container py-5">
        <h1 className="mb-4 text-center">My Registered Events</h1>

        {myEvents.length === 0 ? (
          <p className="text-center">
            You have not registered for any events yet. Please go to{" "}
            <a href="/conference" className="text-primary">Events</a> to register.
          </p>
        ) : (
          <div className="row g-4">
            {myEvents.map(event => (
              <div key={event.id} className="col-md-4">
                <div className="card shadow-sm h-100">
                  <div className="card-body d-flex flex-column">
                    <h5 className="card-title">{event.name}</h5>
                    <p className="card-text">Date: {event.date}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      <Footer />
    </>
  );
};

export default MyEvents;
