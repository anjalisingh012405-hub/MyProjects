// src/pages/participant/Pdash.jsx
import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Header from "../Header";
import Footer from "../Footer";
import { getCurrentUser } from "../../utils/LocalStorageUtils";
import "./Pdash.css";

const Pdash = () => {
  const navigate = useNavigate();

  // Get participant details from LocalStorageUtils
  const currentUser = getCurrentUser();
  const userName = currentUser?.fullName || "Participant"; // Full Name instead of email

  useEffect(() => {
    const adjustPadding = () => {
      const header = document.querySelector("header");
      const main = document.querySelector(".pdash-main");
      if (header && main) {
        main.style.paddingTop = `${header.offsetHeight + 40}px`; // header height + extra space
      }
    };

    adjustPadding(); // adjust on mount
    window.addEventListener("resize", adjustPadding); // adjust on resize
    return () => window.removeEventListener("resize", adjustPadding);
  }, []);

  return (
    <>
      <Header />

      <main className="pdash-main container py-5 text-center">
        <h1 className="mb-4">Welcome, {userName}!</h1>
        <p className="mb-5">
          This is your Participant Dashboard. You can view events and check your registrations.
        </p>

        <div className="row g-4 justify-content-center">
          {/* All Events */}
          <div className="col-md-4">
            <div
              className="card shadow-sm pdash-card"
              onClick={() => navigate("/conference")}
            >
              <div className="card-body">
                <h5 className="card-title">All Events</h5>
                <p>Explore and register for upcoming events.</p>
                <button className="btn btn-primary mt-2">Go</button>
              </div>
            </div>
          </div>

          {/* My Events */}
          <div className="col-md-4">
            <div
              className="card shadow-sm pdash-card"
              onClick={() => navigate("/participant/my-events")}
            >
              <div className="card-body">
                <h5 className="card-title">My Events</h5>
                <p>View events you have registered for.</p>
                <button className="btn btn-primary mt-2">Go</button>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </>
  );
};

export default Pdash;
