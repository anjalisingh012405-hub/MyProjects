// src/event/Conference.jsx
import React from "react";
import { useNavigate } from "react-router-dom";
import Header from "../pages/Header";
import Footer from "../pages/Footer";
import { getCurrentUser, setCurrentUser } from "../utils/LocalStorageUtils";
import "../pages/Home.css"; // Home page ka theme CSS

const Conference = () => {
  const navigate = useNavigate();

  const events = [
    { id: 1, name: "React Conference 2025", date: "2025-12-01", image: "https://tse1.mm.bing.net/th/id/OIP.dW3jXUKtul4DSWOa-IdCNgHaEK?pid=Api&P=0&h=220" },
    { id: 2, name: "AI & ML Workshop", date: "2025-11-20", image: "https://erode-sengunthar.ac.in/wp-content/uploads/2024/02/aiml-image-1.png" },
    { id: 3, name: "Cyber Security Seminar", date: "2025-10-15", image: "https://tse2.mm.bing.net/th/id/OIP.2-GVl506xGrCbw_qYX0kBQHaDq?pid=Api&P=0&h=220" },
    { id: 4, name: "Data Science Meetup", date: "2025-09-30", image: "https://tse2.mm.bing.net/th/id/OIP.FMvBDoSKPl55TBG1e_G6PAHaEo?pid=Api&P=0&h=220" },
    { id: 5, name: "Cloud Computing Workshop", date: "2025-08-25", image: "https://propernewstime.com/wp-content/uploads/2023/01/Cloud-Computing.jpeg" },
    { id: 6, name: "Blockchain Conference", date: "2025-07-10", image: "https://tse4.mm.bing.net/th/id/OIP.2gfNnQca9lq-Qxf1Q_m4PQHaEJ?pid=Api&P=0&h=220" },
    { id: 7, name: "IoT Seminar", date: "2025-06-15", image: "https://static.vecteezy.com/system/resources/previews/012/742/295/large_2x/abstract-internet-of-things-concept-city-5g-iot-internet-of-things-communication-network-innovation-technology-concept-icons-connect-wireless-devices-and-networking-innovation-technology-vector.jpg" },
    { id: 8, name: "DevOps Workshop", date: "2025-05-20", image: "https://www.edureka.co/blog/wp-content/uploads/2019/06/DevOps.png" },
    { id: 9, name: "Python Bootcamp", date: "2025-04-10", image: "https://moodle.sdcollegeambala.org/pluginfile.php/191514/course/overviewfiles/python%20bootcamp.jpg" },
  { id: 10, name: "Kubernetes Meetup", date: "2025-03-18", image: "https://tse1.mm.bing.net/th/id/OIP.DSvseXIXuqTHN4PNefIVyAHaEt?pid=Api&P=0&h=220" },
  { id: 11, name: "Frontend Dev Summit", date: "2025-02-25", image: "https://tse3.mm.bing.net/th/id/OIP.nIwCkshJRg4E_SaoZwAgUAHaD3?pid=Api&P=0&h=220" },
  { id: 12, name: "Agile & Scrum Workshop", date: "2025-01-30", image: "https://kruschecompany.com/wp-content/uploads/2021/09/Agile-software-development-with-Scrum-blog-cover-image.jpg" },

  ];

  const handleRegister = (eventId) => {
    const currentUser = getCurrentUser();

    if (!currentUser) {
      alert("Please login to register for events!");
      navigate("/login");
      return;
    }

    const registeredEvents = currentUser.registeredEvents || [];

    if (registeredEvents.includes(eventId)) {
      return alert("You have already registered for this event!");
    }

    registeredEvents.push(eventId);
    const updatedUser = { ...currentUser, registeredEvents };
    setCurrentUser(updatedUser); // permanent save

    alert("Event registered successfully!");
    navigate("/participant/my-events"); // redirect to MyEvent.jsx
  };

  return (
    <>
      <Header />
      <main className="home-main">
        <section className="featured-events py-5">
          <div className="container">
            <h2 className="text-center mb-4">All Conferences</h2>
            <div className="row g-4 flex-nowrap overflow-auto">
              {events.map((event) => (
                <div key={event.id} className="col flex-shrink-0">
                  <div className="card shadow-sm h-100">
                    <img
                      src={event.image}
                      alt={event.name}
                      className="card-img-top"
                    />
                    <div className="card-body d-flex flex-column">
                      <h5 className="card-title">{event.name}</h5>
                      <p className="card-text">Date: {event.date}</p>
                      <button
                        className="btn btn-primary mt-auto"
                        onClick={() => handleRegister(event.id)}
                      >
                        Register
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
};

export default Conference;
